 /** 
 * @see Console
 * @author Petr (http://www.sallyx.org/)
 */
package common.Debug;

public interface DebugConsole {
    public DebugConsole print(Object T);
}