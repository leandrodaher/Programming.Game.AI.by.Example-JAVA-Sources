/**
 * @author Petr (http://www.sallyx.org/)
 */
package Chapter3Steering;

public class constants {
    //change these values at your peril!
    final public static int constWindowWidth  = 500;
    final public static int constWindowHeight = 500;    
}
