/**
 * @author Petr (http://www.sallyx.org/)
 */
package Chapter3Steering;

public class resource {
//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Script1.rc
//
    public static final int IDR_MENU1 = 101;
    public static final int ID_AID_WANDER = 40001;
    public static final int ID_AID_STEERINGFORCE = 40002;
    public static final int ID_AID_WALLFEELERS = 40003;
    public static final int ID_OB_WALLS = 40004;
    public static final int ID_OB_OBSTACLES = 40005;
    public static final int ID_OB_PATH = 40006;
    public static final int ID_AID_DETECTIONBOX = 40007;
    public static final int IDR_PARTITIONING = 40008;
    public static final int IDR_WEIGHTED_SUM = 40009;
    public static final int IDR_PRIORITIZED = 40010;
    public static final int IDR_DITHERED = 40011;
    public static final int ID_VIEW_KEYS = 40012;
    public static final int ID_VIEW_FPS = 40013;
    public static final int ID_MENU_SMOOTHING = 40014;
    public static final int IDM_PARTITION_VIEW_NEIGHBORS = 40015;

    /*
    // Next default values for new objects
    // 
    #ifdef APSTUDIO_INVOKED
    #ifndef APSTUDIO_READONLY_SYMBOLS
    public static final int _APS_NEXT_RESOURCE_VALUE       = 102;
    public static final int _APS_NEXT_COMMAND_VALUE        = 40016;
    public static final int _APS_NEXT_CONTROL_VALUE        = 1000;
    public static final int _APS_NEXT_SYMED_VALUE          = 101;
    #endif
    #endif
     */
}