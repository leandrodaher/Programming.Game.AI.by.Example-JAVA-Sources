/**
 * @author Petr (http://www.sallyx.org/)
 */
package SimpleSoccer;

public class constants {
    //change these values at your peril!
    final public static int WindowWidth  = 700;
    final public static int WindowHeight = 400;    
    
    //defines the size of a team -- do not adjust
    final int TeamSize = 5;
}
